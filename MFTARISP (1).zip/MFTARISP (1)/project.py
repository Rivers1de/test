import numpy as np
from numpy.linalg import cholesky
import matplotlib.pyplot as plt
import pandas as pd
import copy
import math
import time
import numpy.linalg as nlg

#统计时态序列数据集中的1-序列及其开始标号和支持度
def sequence_1(fuhao,lishudu,window,attributes):
    sNum=len(fuhao)
    S=[]
    SID=[]
    Sup=[]
    for i in range(sNum):
        if i!=(sNum-1): eNum=window
        else: eNum=len(fuhao[-1])-2
        S1=[]
        SID1=[]
        Sup1=[]
        for j in range(2,eNum+2):  #遍历一个序列
            eleFuhao=fuhao[i][j]
            eleLishudu=lishudu[i][j-1]
            for k in range(attributes):
                if eleFuhao[k] not in S1:
                    S1.append(eleFuhao[k])
                    SID1.append(fuhao[i][0])
                    Sup1.append(eleLishudu[k])
                else:
                    a=S1.index(eleFuhao[k])
                    Sup1[a]=max(Sup1[a],eleLishudu[k])
        for j in range(len(S1)):  #整合各序列记录中的1-序列
            if S1[j] in S:
                a=S.index(S1[j])
                Sup[a]=Sup[a]+Sup1[j]
            else:
                S.append(S1[j])
                SID.append(SID1[j])
                Sup.append(Sup1[j])
    for i in range(len(Sup)):   #计算各1-序列的支持度
        Sup[i]=round(Sup[i]/(fuhao[-1][0]-SID[i]+1),3)
    return S,SID,Sup

#从投影数据库中找频繁出现的1-序列
def fre_1_seq(projection_fuhao,projection_lishudu,S,SID,level,supportThr,startThr,lastSID):
    #-----取出前缀中包含的符号，并得到前缀的开始标号
    L=[]
    for ele in projection_fuhao[0][1:]:
        L.extend(ele)
    prefix=L[0:level]
    L=[]
    for ele in prefix:
        a=S.index(ele)
        L.append(SID[a])
    prefix_sid=max(L)
    #-----找1-序列
    s = []
    sid = []
    sup = []
    for i in range(len(projection_fuhao)):  #遍历每条序列记录
        seq =[list(ele) for ele in projection_fuhao[i][1:]]
        mem =[list(ele) for ele in projection_lishudu[i][1:]]
        #-----忽略前缀，得到投影序列
        for j in range(len(seq)):
            if level // len(seq[j]) == 0 and level > 0:
                del seq[j][0:level]
                del mem[j][0:level]
                break
            elif level // len(seq[j]) > 0:
                level = level - len(seq[j])
                del seq[j][:]
                del mem[j][:]
        while [] in seq:
            seq.remove([])
            mem.remove([])
        #-----遍历投影序列，得到该序列中的1-序列
        s1=[]
        sup1=[]
        for j in range(len(seq)):
            for k in range(len(seq[j])):
                if seq[j][k] not in s1:
                    s1.append(seq[j][k])
                    sup1.append(mem[j][k])
                else:
                    a=s1.index(seq[j][k])
                    sup1[a]=max(sup1[a],mem[j][k])
        #-----将各投影序列中的1-序列整合起来，得到投影数据库的1-序列
        for j in range(len(s1)):
            if s1[j] in s:
                a=s.index(s1[j])
                sup[a]=sup[a]+sup1[j]
            else:
                s.append(s1[j])
                sup.append(sup1[j])
    #-----计算1-序列的开始标号
    for i in range(len(s)):
        a=S.index(s[i])
        sid.append(max(prefix_sid,SID[a]))
    #-----计算1-序列的支持度
    for i in range(len(sup)):
        sup[i]=round(sup[i]/(lastSID-sid[i]+1),3)
    #-----删除不满足阈值的1-序列，得到频繁发生的1-序列
    for i in range(len(sid)-1,-1,-1):
        if (lastSID - sid[i] + 1) < startThr or sup[i] < supportThr:
            del s[i],sid[i],sup[i]
    return s,sid,sup

#深度优先递归挖掘序列模式
def recursion(projection_fuhao,projection_lishudu,S,SID,level,supportThr,startThr,lastSID,window,attributes,allPatterns,
              projection1_fuhao,projection1_lishudu):
    s,sid,sup=fre_1_seq(projection_fuhao,projection_lishudu,S,SID,level,supportThr,startThr,lastSID)# 找频繁出现的1-序列
    if s==[]:  #递归停止条件
        pass
    else:  #递归继续
        #-----取出前缀
        seq = projection_fuhao[0][1:]
        prefix = []
        num = level
        for i in range(len(seq)):
            if num // len(seq[i]) == 0 and num > 0:
                prefix.append(list(seq[i][:num]))
                break
            elif num // len(seq[i]) > 0:
                num = num - len(seq[i])
                prefix.append(list(seq[i]))
        #-----用前缀和1-序列构造可能的模式
        Patterns=[]
        Patt_SID=[]
        for i in range(len(s)):  #遍历找到的每个1-序列
            if len(prefix)<window:
                pattern = [list(ele) for ele in prefix]
                pattern.append([s[i]])
                Patterns.append(list(pattern))
                Patt_SID.append(int(sid[i]))
            if len(prefix[-1])<attributes:
                L1=prefix[-1]
                L2=''.join(L1)
                if L2.find(s[i][0])==-1:
                    num=0
                    for j in range(len(L1)):
                        if L1[j]<s[i]:
                            num+=1
                        else: break
                    if num==len(L1):
                        pattern = [list(ele) for ele in prefix]
                        pattern[-1].append(s[i])
                        Patterns.append(list(pattern))
                        Patt_SID.append(int(sid[i]))
        #-----计算各可能模式的支持度
        Patt_sup = [[] for x in Patterns]
        for i in range(len(Patterns)):
            for j in range(len(Patterns[i])):
                if j == 0:
                    pre_ele = Patterns[i][0]
                    LLL = []
                    for k in range(len(projection1_fuhao)):
                        if projection1_fuhao[k][0] >= Patt_SID[i]:
                            seq1 = projection1_fuhao[k][1:]
                            sup1 = projection1_lishudu[k][1:]
                            LL = []
                            for p in range(len(seq1)):
                                num = 0
                                for q in range(len(pre_ele)):
                                    if pre_ele[q] in seq1[p]:
                                        num += 1
                                    else:
                                        break
                                if num == len(pre_ele):
                                    L = []
                                    for ele in pre_ele:
                                        L.append(sup1[p][seq1[p].index(ele)])
                                    a = min(L)
                                    LL.append(a)
                            if LL != []:
                                a = max(LL)
                                LLL.append(a)
                    sup = round(sum(LLL) / (projection1_fuhao[-1][0] - Patt_SID[i] + 1),3)
                    Patt_sup[i].append(sup)
                else:
                    pre_ele = Patterns[i][0:(j + 1)]
                    LLL = []
                    for k in range(len(projection1_fuhao)):
                        if projection1_fuhao[k][0] >= Patt_SID[i]:
                            seq2 = projection1_fuhao[k][1:]
                            sup2 = projection1_lishudu[k][1:]
                            n = 0
                            LL = []
                            for p in range(len(seq2)):
                                a = 0
                                L = []
                                for q in range(len(pre_ele[n])):
                                    if pre_ele[n][q] in seq2[p]:
                                        a += 1
                                        L.append(sup2[p][seq2[p].index(pre_ele[n][q])])
                                    else:
                                        break
                                if a == len(pre_ele[n]):
                                    n += 1
                                    LL.extend(L)
                                if n >= len(pre_ele):
                                    break
                            a = 0
                            for ele in pre_ele:
                                a += len(ele)
                            if len(LL) == a:
                                LLL.append(min(LL))
                    sup = round(sum(LLL) / (projection1_fuhao[-1][0] - Patt_SID[i] + 1),3)
                    Patt_sup[i].append(sup)
        #-----删除不满足支持度阈值的可能模式，得到真正的模式
        for i in range(len(Patt_sup)-1,-1,-1):
            if Patt_sup[i][-1]<supportThr:
                del Patterns[i],Patt_SID[i],Patt_sup[i]
        if Patterns==[]:   #递归停止条件
            pass
        else:   #递归继续
            #-----重新构造模式的格式，存储在allPatterns列表中
            for i in range(len(Patterns)):
                L=[]
                L.append(Patterns[i])
                L.append(Patt_SID[i])
                L.append(Patt_sup[i])
                allPatterns.append(L)
            #-----为每个模式构造新的投影数据库
            new_projection_fuhao = []
            new_projection_lishudu = []
            for i in range(len(Patterns)):
                LLL_fuhao = []
                LLL_lishudu = []
                for j in range(len(projection_fuhao)):
                    if projection_fuhao[j][0] >= Patt_SID[i] and len(projection_fuhao[j][1:]) >= len(Patterns[i]):
                        seq3 = [list(ele) for ele in projection_fuhao[j][1:]]
                        sup3 = [list(ele) for ele in projection_lishudu[j][1:]]
                        n = 0
                        LL_sup = []
                        LL_seq = []
                        for k in range(len(seq3)):
                            a = 0
                            L_sup = []
                            L_seq = []
                            for p in range(len(Patterns[i][n])):
                                if Patterns[i][n][p] in seq3[k]:
                                    a += 1
                                    suoyin = seq3[k].index(Patterns[i][n][p])
                                    L_sup.append(sup3[k][suoyin])
                                    L_seq.append(seq3[k][suoyin])
                                else:
                                    if k == (len(seq3) - 1):
                                        LL_seq = []
                                        LL_sup = []
                                    break
                            if a == len(Patterns[i][n]):
                                n += 1
                                LL_seq.append(list(L_seq))
                                LL_sup.append(list(L_sup))
                                if n < len(Patterns[i]):
                                    continue
                                else:
                                    if (suoyin + 1) < len(seq3[k]):
                                        LL_seq[-1].extend(seq3[k][suoyin + 1:])
                                        LL_sup[-1].extend(sup3[k][suoyin + 1:])
                                    if k + 1 < len(seq3):
                                        LL_seq.extend(seq3[k + 1:])
                                        LL_sup.extend(sup3[k + 1:])
                                    break
                        if LL_seq != []:
                            L1 = [list(ele) for ele in LL_seq]
                            L2 = [list(ele) for ele in LL_sup]
                            L1.insert(0, projection_fuhao[j][0])
                            L2.insert(0, projection_lishudu[j][0])
                            LLL_fuhao.append(L1)
                            LLL_lishudu.append(L2)
                new_projection_fuhao.append(LLL_fuhao)
                new_projection_lishudu.append(LLL_lishudu)
            level+=1
            for i in range(len(new_projection_fuhao)):
                recursion(new_projection_fuhao[i], new_projection_lishudu[i], S, SID, level, supportThr, startThr, lastSID, window,
                      attributes, allPatterns,projection1_fuhao, projection1_lishudu)

#挖掘规则
def getRules(allPatterns,confidenceThr,SID_Time,endTime):
    Rules=[]
    for i in range(len(allPatterns)):
        if len(allPatterns[i][0])>=2:
            for j in range(len(allPatterns[i][0])-1):
                conf=round(allPatterns[i][-1][-1]/allPatterns[i][-1][j],3)
                if conf>=confidenceThr:
                    #-----构造规则前件
                    seq=allPatterns[i][0][:j+1]
                    L1=[]
                    for k in range(len(seq)):
                        if len(seq[k])>1:
                            S1=','.join(seq[k])
                            S1='('+S1+')'
                            L1.append(S1)
                        else:
                            L1.append(seq[k][0])
                    antecedent=''.join(L1)
                    #-----构造规则后件
                    seq = allPatterns[i][0][j + 1:]
                    L2 = []
                    for k in range(len(seq)):
                        if len(seq[k]) > 1:
                            S1 = ','.join(seq[k])
                            S1 = '(' + S1 + ')'
                            L2.append(S1)
                        else:
                            L2.append(seq[k][0])
                    consequent = ''.join(L2)
                    #-----构造规则的有效时间区间
                    for k in range(len(SID_Time)):
                        if SID_Time[k][0]==allPatterns[i][1]:
                            valid_interval='['+str(SID_Time[k][1])+','+str(endTime)+']'
                            break
                    #-----构造规则的支持度、置信度
                    support=str(allPatterns[i][-1][-1])
                    confidence = str(conf)
                    #-----合成一条规则
                    rule=antecedent+'-->'+consequent+','+valid_interval+',sup='+support+',conf='+confidence
                    Rules.append(rule)
    return Rules

#将之前找到的1-模式与当前1-序列进行合并
def sequenceMerge(S,SID,Sup,S1,SID1,Sup1,Lfuhao,lastSID):
    for i in range(len(S)):
        if S[i] in S1:
            suoyin=S1.index(S[i])
            Sup[i]=round((Sup[i]*(Lfuhao[0][0]-SID[i])+Sup1[suoyin]*(lastSID-SID1[suoyin]+1))/(lastSID-SID[i]+1),3)
            del S1[suoyin],SID1[suoyin],Sup1[suoyin]
        else:
            Sup[i] = round(Sup[i]*(Lfuhao[0][0]-SID[i])/(lastSID-SID[i]+1),3)
    if S1!=[]:
        S.extend(S1)
        SID.extend(SID1)
        Sup.extend(Sup1)

#删除不满足支持度阈值和开始标号阈值的1-序列，得到新的1-模式集合
def get_1_pattern(S,SID,Sup,supportThr,startThr,lastSID):
    for i in range(len(S)-1,-1,-1):
        if Sup[i]<supportThr or (lastSID-SID[i]+1)<startThr:
            del S[i],SID[i],Sup[i]

#更新1-模式投影数据库
def update_1_pattern(S_copy,S,projection1_fuhao,projection1_lishudu):
    for i in range(len(S_copy)):
        if S_copy[i] not in S:
            for j in range(len(projection1_fuhao)-1,-1,-1):
                if projection1_fuhao[j][0][1][0]==S_copy[i]:
                    del projection1_fuhao[j],projection1_lishudu[j]
                else:
                    for k in range(len(projection1_fuhao[j])-1,-1,-1):
                        for p in range(1,len(projection1_fuhao[j][k])):
                            if S_copy[i] in projection1_fuhao[j][k][p]:
                                suoyin=projection1_fuhao[j][k][p].index(S_copy[i])
                                del projection1_fuhao[j][k][p][suoyin],projection1_lishudu[j][k][p][suoyin]
                        while [] in projection1_fuhao[j][k]:
                            projection1_fuhao[j][k].remove([])
                            projection1_lishudu[j][k].remove([])
                        if len(projection1_fuhao[j][k])==1:
                            del projection1_fuhao[j][k],projection1_lishudu[j][k]

#基于增量数据库为当前所有1-模式构造投影数据库
def create_projection(S,Lfuhao,Llishudu,projection1_fuhao2,projection1_lishudu2):
    for i in range(len(S)):  #对每个1-模式分别构造投影数据库
        L1=[]
        L2=[]
        for j in range(len(Lfuhao)):  #遍历每条序列记录
            seq=[list(ele) for ele in Lfuhao[j][2:]]
            sup=[list(ele) for ele in Llishudu[j][1:]]
            for m in range(len(seq)):  #忽略非频繁项
                for n in range(len(seq[m])-1,-1,-1):
                    if seq[m][n] not in S:
                        del seq[m][n],sup[m][n]
            LL1=[]
            LL2=[]
            for p in range(len(seq)):
                if S[i] in seq[p]:
                    num=seq[p].index(S[i])
                    LL1.append(seq[p][num:])
                    LL2.append(sup[p][num:])
                    if p!=(len(seq)-1):
                        LL1.extend(seq[p+1:])
                        LL2.extend(sup[p+1:])
                        break
            if LL1!=[]:
                LL1.insert(0,Lfuhao[j][0])
                LL2.insert(0,Lfuhao[j][0])
                L1.append(LL1)
                L2.append(LL2)
        if L1!=[]:
            projection1_fuhao2.append(L1)
            projection1_lishudu2.append(L2)

#-----合并新、旧1-模式投影数据库
def projectionMerge(projection1_fuhao,projection1_lishudu,projection1_fuhao2,projection1_lishudu2):
    for i in range(len(projection1_fuhao)):
        for j in range(len(projection1_fuhao2)):
            if projection1_fuhao[i][0][1][0]==projection1_fuhao2[j][0][1][0]:
                projection1_fuhao[i].extend(projection1_fuhao2[j])
                projection1_lishudu[i].extend(projection1_lishudu2[j])









window=5  #窗口大小
supportThr=0.1  #支持度阈值
confidenceThr=0.6  #置信度阈值
startThr=2  #最少记录数阈值

##########DB0的挖掘###########
fuhao=pd.read_excel('DB1(fuhao).xlsx')
lishudu=pd.read_excel('DB1(lishudu).xlsx')
trans=fuhao.shape[0]
attributes=fuhao.shape[1]-3
#-------构造序列数据集（符号）
ele1=0
s,e=0,0
ele2=[s,e]
Lfuhao=[]
for i in range(trans//window):
    l=[]
    ele1+=1
    sIndex=i*window
    eIndex=(i+1)*window-1
    s=fuhao.iloc[sIndex,1]
    e=fuhao.iloc[eIndex,2]
    ele2 = [s,e]
    l.extend([ele1,ele2])
    ele3=[]
    for j in range(sIndex,eIndex+1):
        ele3=list(fuhao.iloc[j,3:])
        l.append(ele3)
    Lfuhao.append(l)
ele1+=1
if trans%window!=0:
    s=fuhao.iloc[trans-trans%window,1]
    e=fuhao.iloc[trans-1,2]
    ele2 = [s,e]
    l=[ele1,ele2]
    for i in range(trans-trans%window,trans):
        ele3 = list(fuhao.iloc[i, 3:])
        l.append(ele3)
    Lfuhao.append(l)
#-------构造序列数据集（隶属度）
ele1=0
Llishudu=[]
for i in range(trans//window):
    l=[]
    ele1+=1
    sIndex=i*window
    eIndex=(i+1)*window-1
    l.append(ele1)
    ele3=[]
    for j in range(sIndex,eIndex+1):
        ele3=[round(x,3) for x in list(lishudu.iloc[j,:])]
        l.append(ele3)
    Llishudu.append(l)
ele1+=1
l=[ele1]
for i in range(trans-trans%window,trans):
    ele3 = [round(x,3) for x in list(lishudu.iloc[i,:])]
    l.append(ele3)
    Llishudu.append(l)
#-----保存每个开始标号对应的开始时间
SID_Time=[]
for i in range(len(Lfuhao)):
    L = []
    L.append(int(Lfuhao[i][0]))
    L.append(int(Lfuhao[i][1][0]))
    SID_Time.append(L)
endTime=int(Lfuhao[-1][1][-1])
#-------找1-模式
lastSID=Lfuhao[-1][0]
S,SID,Sup=sequence_1(Lfuhao[:],Llishudu[:],window,attributes)  #找1-序列
for i in range(len(SID)-1,-1,-1): #删除不满足阈值的1-序列，得到1-模式
    if (lastSID-SID[i]+1)<startThr or Sup[i]<supportThr:
        del S[i],SID[i],Sup[i]
#-------找1-模式投影数据库
projection1_fuhao=[]
projection1_lishudu=[]
for i in range(len(S)):  #对每个1-模式分别构造投影数据库
    L1=[]
    L2=[]
    for j in range(len(Lfuhao)):  #遍历每条序列记录
        seq=[list(ele) for ele in Lfuhao[j][2:]]
        sup=[list(ele) for ele in Llishudu[j][1:]]
        for m in range(len(seq)):  #忽略非频繁项
            for n in range(len(seq[m])-1,-1,-1):
                if seq[m][n] not in S:
                    del seq[m][n],sup[m][n]
        LL1=[]
        LL2=[]
        for p in range(len(seq)):
            if S[i] in seq[p]:
                num=seq[p].index(S[i])
                LL1.append(seq[p][num:])
                LL2.append(sup[p][num:])
                if p!=(len(seq)-1):
                    LL1.extend(seq[p+1:])
                    LL2.extend(sup[p+1:])
                    break
        if LL1!=[]:
            LL1.insert(0,Lfuhao[j][0])
            LL2.insert(0,Lfuhao[j][0])
            L1.append(LL1)
            L2.append(LL2)
    projection1_fuhao.append(L1)
    projection1_lishudu.append(L2)
#-------挖掘所有模式
allPatterns=[]
for i in range(len(projection1_fuhao)):
    level=1
    recursion(projection1_fuhao[i],projection1_lishudu[i],S,SID,level,supportThr,startThr,lastSID,window,attributes,
              allPatterns,projection1_fuhao[i],projection1_lishudu[i])
#--------输出挖掘出的模式
print(S)
pattern3=copy.deepcopy(allPatterns)
print('**************moshi**********************')
print(pattern3)
print('************************************')
Patterns=[]
for i in range(len(pattern3)):
    Patterns.append(pattern3[i][0])
print(Patterns)

Lfuhao1=[]
for i in range(len(Lfuhao)):
    Lfuhao1.append(Lfuhao[i][2:])
print(Lfuhao1)
pattern1=copy.deepcopy(Patterns)

for i in range(len(Patterns)): #找出序列模式内相邻每个项在每个序列的间隔
    for j in range(len(Patterns[i])):
        if len(Patterns[i]) == 1:
            pattern1[i][j].append([])
        else:

            if len(Patterns[i][j])<2:
                searchval = np.array(Patterns[i][j])
                L=[]
                for k in range(len(Lfuhao1)):
                    L.append((np.where(Lfuhao1[k] == searchval)[0]).tolist())
                pattern1[i][j].append(L)
            else:
                pattern1[i][j].append([])
                for m in range(len(Lfuhao1)):
                    X = []
                    for k in range(len(Lfuhao1[m])):
                        p = set(Patterns[i][j]).issubset(set(Lfuhao1[m][k]))
                        if p:
                            X.append(k)
                    pattern1[i][j][-1].append(X)
print(allPatterns)
z=copy.deepcopy(allPatterns)
for s in range(len(pattern1)):
    if len(pattern1[s]) == 1:
        continue
    else:
        time=[]
        x=0
        for i in range(len(pattern1[s])-1):
            X=[]
            min_interval=[]
            max_interval=[]
            for j in range(len(pattern1[s][i][-1])):
                if pattern1[s][i][-1][j]==[] or pattern1[s][i+1][-1][j]==[]:
                    continue
                else:
                    for m in range(len(pattern1[s][i][-1][j])):
                        for k in range(len(pattern1[s][i+1][-1][j])):
                            M=pattern1[s][i][-1][j][m]-pattern1[s][i+1][-1][j][k]
                            if M < 0:
                                X.append(abs(M))
            min_interval.append(min(X))
            max_interval.append(max(X))
            if min_interval[0]==max_interval[0]:
                interval=[min_interval[0]]
            else:
                interval=[min_interval[0],max_interval[0]]
            Patterns[s].insert(x+1,interval)
            x=x+2
# print(allPatterns)
# print(z)
# print(pattern1)
# print(Patterns)



print('*****所有找到的模式:*****')
# print('Patterns in DB[0]:')
pattern=copy.deepcopy(allPatterns)
for i in range(len(pattern)):
    pattern[i][0]=Patterns[i]
    print(pattern[i])

print(allPatterns)

# print('Patterns in DB[0]:')
# for i in range(len(allPatterns)):
#     print(allPatterns[i])
print('Number of patterns:',i+1)
#--------从模式中获得规则
Rules=getRules(allPatterns,confidenceThr,SID_Time,endTime)
#--------输出挖掘出的规则
# print('Rules in DB[0]:')
#     for i in range(len(Rules)):
#         print(Rules[i])
# print('Number of rules:',i+1)
# print('********************************************************')



##########DB1的挖掘###########
fuhao=pd.read_excel('DB2(fuhao).xlsx')
lishudu=pd.read_excel('DB2(lishudu).xlsx')
trans=fuhao.shape[0] #事务条数

#-------构造序列数据集（符号）
ele1=SID_Time[-1][0]
s,e=0,0
ele2=[s,e]
Lfuhao=[]
for i in range(trans//window):
    l=[]
    ele1+=1
    sIndex=i*window
    eIndex=(i+1)*window-1
    s=fuhao.iloc[sIndex,1]
    e=fuhao.iloc[eIndex,2]
    ele2 = [s,e]
    l.extend([ele1,ele2])
    ele3=[]
    for j in range(sIndex,eIndex+1):
        ele3=list(fuhao.iloc[j,3:])
        l.append(ele3)
    Lfuhao.append(l)
ele1+=1
if trans%window!=0:
    s=fuhao.iloc[trans-trans%window,1]
    e=fuhao.iloc[trans-1,2]
    ele2 = [s,e]
    l=[ele1,ele2]
    for i in range(trans-trans%window,trans):
        ele3 = list(fuhao.iloc[i, 3:])
        l.append(ele3)
    Lfuhao.append(l)
#-------构造序列数据集（隶属度）
ele1=SID_Time[-1][0]
Llishudu=[]
for i in range(trans//window):
    l=[]
    ele1+=1
    sIndex=i*window
    eIndex=(i+1)*window-1
    l.append(ele1)
    ele3=[]
    for j in range(sIndex,eIndex+1):
        ele3=[round(x,3) for x in list(lishudu.iloc[j,:])]
        l.append(ele3)
    Llishudu.append(l)
ele1+=1
l=[ele1]
for i in range(trans-trans%window,trans):
    ele3 = [round(x,3) for x in list(lishudu.iloc[i,:])]
    l.append(ele3)
    Llishudu.append(l)
#-----将新的开始标号开始时间对附加到SID_Time列表
for i in range(len(Lfuhao)):
    L = []
    L.append(int(Lfuhao[i][0]))
    L.append(int(Lfuhao[i][1][0]))
    SID_Time.append(L)
endTime=int(Lfuhao[-1][1][-1])
#-----找1-序列
lastSID=Lfuhao[-1][0]
S1,SID1,Sup1=sequence_1(Lfuhao[:],Llishudu[:],window,attributes)
#-----将之前找到的1-模式与当前1-序列进行合并
S_copy=list(S)
SID_copy=list(SID)
Sup_copy=list(Sup)
sequenceMerge(S,SID,Sup,S1,SID1,Sup1,Lfuhao,lastSID)
#-----删除不满足支持度阈值和开始标号阈值的1-序列，得到新的1-模式集合
get_1_pattern(S,SID,Sup,supportThr,startThr,lastSID)
#-----更新1-模式投影数据库
update_1_pattern(S_copy,S,projection1_fuhao,projection1_lishudu)
#-----基于增量数据库为当前所有1-模式构造投影数据库
projection1_fuhao2=[]
projection1_lishudu2=[]
create_projection(S,Lfuhao,Llishudu,projection1_fuhao2,projection1_lishudu2)
#-----合并新、旧1-模式投影数据库
projectionMerge(projection1_fuhao,projection1_lishudu,projection1_fuhao2,projection1_lishudu2)
#-------挖掘所有模式
allPatterns=[]
for i in range(len(projection1_fuhao)):
    level=1
    recursion(projection1_fuhao[i],projection1_lishudu[i],S,SID,level,supportThr,startThr,lastSID,window,attributes,
              allPatterns,projection1_fuhao[i],projection1_lishudu[i])
#--------输出挖掘出的模式

# print('Patterns in DB[0]+DB[1]:')
# for i in range(len(allPatterns)):
#     print(allPatterns[i])
# print('Number of patterns:',i+1)


#--------从模式中获得规则
# Rules=getRules(allPatterns,confidenceThr,SID_Time,endTime)
#--------输出挖掘出的规则
# print('Rules in DB[0]+DB[1]:')
# for i in range(len(Rules)):
    # print(Rules[i])

# print(Rules)
# print('Number of rules:',i+1)
# print('********************************************************')





